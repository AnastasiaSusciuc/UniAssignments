#include "SortedSetIterator.h"
#include <exception>
#include <iostream>

using namespace std;

// O(log sizeSet)
SortedSetIterator::SortedSetIterator(const SortedSet& m) : multime(m)
{
    Travers = new int[m.setSize];
    ordered = new int[m.setSize];

    int node = m.bst.root;
    count = -1;
    top = -1;

    if (node != -1)
    {
        while (node != NULL_POS)
        {
            Travers[++top] = node;
            node = m.bst.left[node];
        }
    }
    while (true)
    {
        if (top == -1)
            break;
        node = Travers[top];
        top--;

        ordered[++count] = m.bst.info[node];
        if (m.bst.right[node] != NULL_POS)
        {
            node = m.bst.right[node];
            while (node != NULL_POS)
            {
                Travers[++top] = node;
                node = m.bst.left[node];
            }
        }

    }

//    for (int i = 0; i <= count; i++)
//        std::cout << ordered[i] << " ";
    first();
}

// O(1)
void SortedSetIterator::first() {
    currentNode = 0;
}

// O(1)
void SortedSetIterator::next() {

    if (!valid())
        throw std::exception();
    currentNode++;
}

// theta(1)
TElem SortedSetIterator::getCurrent()
{
    if (!valid())
        throw std::exception();
    return ordered[currentNode];
}

// theta(1)
bool SortedSetIterator::valid() const {
//    std::cout << "VALID " << currentNode << " " << count << '\n';
    if (currentNode <= -1 || currentNode > count)
        return false;
    return true;
}

void SortedSetIterator::prev() {
    currentNode--;
}
