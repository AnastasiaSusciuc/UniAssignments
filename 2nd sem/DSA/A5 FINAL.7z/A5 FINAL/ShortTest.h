#pragma once

void testAll();
