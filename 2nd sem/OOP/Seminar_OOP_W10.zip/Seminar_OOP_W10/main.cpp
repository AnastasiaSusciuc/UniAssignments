#include <iostream>
#include "tests/test.h"

int main() {

    Tests test;
    test.run_all_tests();


    return 0;
}
