//
// Created by susci on 4/27/2021.
//

#ifndef OOP_TEST_H
#define OOP_TEST_H
#include <iostream>

class Tests{
public:
    void run_all_tests();
};

#endif //OOP_TEST_H
