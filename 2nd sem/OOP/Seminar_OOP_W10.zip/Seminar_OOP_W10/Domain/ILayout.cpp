//
// Created by susci on 4/27/2021.
//

#include "ILayout.h"

ILayout::ILayout(): IBasicComponent(0, 0, 0){

}
