#include <fstream>
#include <iostream>
#include "TestDG/testDG.h"
#include <chrono>
using namespace std::chrono;

int main() {

    TestDG::run_all_tests();
//    DirectedGraph g;
//    read_graph_from_file(g);


    return 0;
}
